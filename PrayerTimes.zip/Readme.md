Islamic Prayer Times for Arduino
===========
Been tested on Arduino :
- Mega 2560
- Uno

Adabted for arduino from this site: http://praytimes.org/manual/
